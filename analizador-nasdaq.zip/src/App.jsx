function App() {
  return <h1>Bienvenido al Analizador Nasdaq</h1>;
}

export default App;