# Analizador Nasdaq

Este es un proyecto en Vite + React con TailwindCSS para analizar acciones del NASDAQ usando análisis técnico.